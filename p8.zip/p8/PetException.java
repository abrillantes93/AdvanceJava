// Anthony Brillantes
// COP 2805C – 91339
// 07/19/2024
// P8 
package p8;

public class PetException extends Exception{
    public PetException(String msg)
    {   
        super(msg);
    }
}
