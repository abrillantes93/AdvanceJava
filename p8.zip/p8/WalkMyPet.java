// Anthony Brillantes
// COP 2805C – 91339
// 07/19/2024
// P8 
package p8;

public interface WalkMyPet 
{
    /* method walk() accepts a String of where the pet is going for the walk
returns a String with a message describing how this pet gets walked
for example:
System.out.println(Obj.cook("the park"));
// prints to screen: "Fido is going for a walk and wagging his tail in the
park."
*/
    public abstract String walk(String whatIsBeingWalked); 
} 
